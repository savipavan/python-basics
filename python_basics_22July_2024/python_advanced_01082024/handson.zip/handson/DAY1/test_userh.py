"""
Execute 
pytest -v test_userh.py 

With coverage 
pytest  --cov=userh --cov-report term-missing test_userh.py 


"""
"""
https://docs.pytest.org/en/6.2.x/assert.html
    Testing exception etc 
https://docs.pytest.org/en/6.2.x/fixture.html
    test data , setup and teardown 
https://docs.pytest.org/en/6.2.x/capture.html
    capture stdout and stderr 
https://docs.pytest.org/en/6.2.x/skipping.html
    skipping based on condition 
    filtering test case
https://docs.pytest.org/en/6.2.x/usage.html
    command line usage 
https://docs.pytest.org/en/6.2.x/monkeypatch.html
    mock testing 

Filtering testcase 
    Usage mark 
    Using K expr 
      -k EXPRESSION         Only run tests which match the given substring expression. An
                        expression is a Python evaluatable expression where all names are
                        substring-matched against test names and their parent classes.
                        Example: -k 'test_method or test_other' matches all test functions
                        and classes whose name contains 'test_method' or 'test_other', while
                        -k 'not test_method' matches those that don't contain 'test_method'
                        in their names. -k 'not test_method and not test_other' will
                        eliminate the matches. Additionally keywords are matched to classes
                        and functions containing extra names in their 'extra_keyword_matches'
                        set, as well as functions which have names assigned directly to them.
                        The matching is case-insensitive.
    # Run only silver case 
    pytest -v -k "Silver" test_userh.py 
    #Run only silver and gold case 
    pytest -v -k "Silver or Gold" test_userh.py
    #Run all from TestUser suite 
    pytest -v -k "TestUser" test_userh.py
    #Run all except TestUSer 
    pytest -v -k "not TestUser" test_userh.py
    
    Testcase name 
    test_userh.py::TestUser::test_normal_user PASSED                                      [ 25%]
    test_userh.py::TestUser::test_Gold_user PASSED                                        [ 50%]
    test_userh.py::TestUser::test_Silver_user PASSED                                      [ 75%]
    test_userh.py::test_ba_str PASSED
    
"""
from userh import *
#Testcase - fn starting with test 
#module name starting with test 
#all test modules are in tests/ 
#test suite is a class starting with Test 


class TestUser: 
    def test_normal_user(self):
        u = NormalUser("Normal", 100)
        amounts = [100, -200, 300, -400, 400]
        for am in amounts :
            u.transact(am)
        assert u.account.amount == 700         
    def test_Gold_user(self):
        u = GoldUser("Normal", 100)
        amounts = [100, -200, 300, -400, 400]
        for am in amounts :
            u.transact(am)
        assert u.account.amount == 710     
    def test_Silver_user(self):
        u = SilverUser("Normal", 100)
        amounts = [100, -200, 300, -400, 400]
        for am in amounts :
            u.transact(am)
        assert u.account.amount == 706
        
def test_ba_str():
    ba = BankAccount(100)
    assert str(ba) == "BankAccount(100)"